package com.example.composetest

import android.os.Bundle
import android.widget.Space
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.composetest.ui.theme.ComposeTestTheme
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            myPreview()
        }
    }
}


@Preview(showBackground = true)
@Composable
fun myPreview() {
    entirePage()
}

@Composable
fun entirePage() {
    var minRange by remember { mutableStateOf(0) }
    var maxRange by remember { mutableStateOf(100) }
    var sliderValue by remember {
        mutableStateOf((minRange + maxRange) / 2)
    }
    var targetValue by remember {
        mutableStateOf(Random.nextInt(0, 100))
    }

    var score by remember { mutableStateOf(0) }
    var totalScore by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf("Your current score: $score") }
    var totalScoreMessage by remember { mutableStateOf("Your total score so far: $totalScore") }
    var bottomMessage by remember { mutableStateOf( "You have not scored anything so far.") }
    fun checkNumber(number: Int): String {
        return when {
            number > 0 -> "Positive"
            number < 0 -> "Negative"
            else -> "Zero"
        }
    }

    Column(modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Bull's Eye Game", fontSize = 24.sp,
            color = Color.Gray, modifier = Modifier.padding(top = 32.dp))
        //Spacer(modifier = Modifier.height(16.dp))
        Text("Move the slider as close as you can to $targetValue", fontSize = 16.sp)

        //Spacer(modifier = Modifier.height(16.dp))
        //Spacer(modifier = Modifier.height(16.dp))

        Slider(value = sliderValue.toFloat(),
            onValueChange = {newValue -> sliderValue = newValue.toInt()},
            valueRange = minRange.toFloat()..maxRange.toFloat(),
            modifier = Modifier.padding(start = 16.dp, end = 16.dp)
        )

        //Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            if(sliderValue in (targetValue - 3)..(targetValue+3)) {
                score = 5
                totalScore += score
                totalScoreMessage = "Your total score so far: $totalScore"
                message = "Your current score: $score"
                bottomMessage = "Perfect! You scored $score points."
                targetValue = Random.nextInt(0, 100)
                sliderValue = (minRange + maxRange) / 2
            } else if(sliderValue in (targetValue - 8)..(targetValue + 8)) {
                score = 1
                totalScore += score
                totalScoreMessage = "Your total score so far: $totalScore"
                message = "Your current score: $score"
                bottomMessage = "Not so accurate. This time you have scored only $score point."
                targetValue = Random.nextInt(0, 100)
                sliderValue = (minRange + maxRange) / 2
            } else {
                score = 0
                bottomMessage = "Very far! Try again."
                message = "Your current score: $score"
                targetValue = Random.nextInt(0, 100)
                sliderValue = (minRange + maxRange) / 2

            }

        }, modifier = Modifier.padding(8.dp)) {
            Text("Hit Me!")
        }

        //Spacer(modifier = Modifier.height(16.dp))

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = message, fontSize = 20.sp, modifier = Modifier.padding(bottom = 16.dp))
            Text(text = totalScoreMessage, fontSize = 20.sp, modifier = Modifier.padding(top = 16.dp))
        }

        Text(text = bottomMessage,
            fontSize = 16.sp,
            modifier = Modifier.padding(bottom = 48.dp),
            color = Color.Gray)


    }
}