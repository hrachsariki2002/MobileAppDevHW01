package com.example.cities_mobile_dubl2.model

data class City(val name: String, val description: String, val imageRes: Int)

