package com.example.hw01

import android.os.Build
import androidx.annotation.RequiresApi
import java.lang.Exception
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@RequiresApi(Build.VERSION_CODES.O)
fun main() {

    // EX 1
    println("Ex 1")
    var firstArray = Array<Int>(5) {0}
    firstArray[0] = 0
    firstArray[1] = 1
    firstArray[2] = 2
    firstArray[3] = 3
    firstArray[4] = 4

    for(element in firstArray) {
        println(element)
    }


    var myList = listOf<String>("Hrach", "Arthur", "Armen", "Hakob")

    for(name in myList) {
        println(name)
    }

    // EX 2
    println("")
    println("Ex 2")
    var randomString = "Hello world!"

    // String concatenation
    var intro = "Introduction: $randomString"
    var anotherIntro = "New intro: " + randomString
    println(intro)
    println(anotherIntro)

    // Substring extraction
    var mySubString = randomString.substring(1,4)
    println(mySubString)

    // Changing case
    var upperString = randomString.uppercase()
    println(upperString)

    var lowerString = randomString.lowercase()
    println(lowerString)

    // EX 3
    println("")
    println("Ex 3")
    var myMap = mapOf<String, Int>("Hrach" to 21, "Arthur" to 23, "Armen" to 21)


    for(key in myMap.keys) {
        println("Key: $key, value: ${myMap[key]}")
    }

    // Ex 4
    // the function is declared outside of the main function
    println("")
    println("Ex 4")

    checkSign(5)
    checkSign(-1)
    checkSign(0)


    // EX 5
    // the function is declared outside of the main function
    println("")
    println("Ex 5")
    userInputFunc()

    // EX 6
    // the function is declared outside of the main function
    println("")
    println("Ex 6")
    divisionFunc()

    //EX 7
    println("")
    println("Ex 7")
    var currentDateTime = LocalDateTime.now()
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
    // Format the current date and time
    val formattedDateTime = currentDateTime.format(formatter)
    println("Current date and time is: $formattedDateTime")

    //EX 8
    // The person class definition is outside of the main function
    println("")
    println("Ex 8")
    var personObj = Person("Hrach", 21)
    personObj.displayPerson()

    //EX 9
    // the class extension is outside of the main function
    println("")
    println("Ex 9")
    var maleObj = Male("Hrach", 21)
    maleObj.lifeStage()

    //EX 10
    println("")
    println("Ex 10")
    var intList = listOf<Int>(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    println("Even numbers: ${intList.filter { it % 2 == 0 }}")


}

// EX 4 function declaration
fun checkSign(a: Int) {
    if(a > 0) {
        println("The input integer is positive")
    } else if (a < 0) {
        println("The input integer is negative")
    } else {
        println("The input integer is zero")
    }


}

// EX 5 function declaration
fun userInputFunc() {

    println("Please enter your name: ")
    val name = readLine() ?: ""

    println("Please enter your age: ")
    val ageInput = readLine() ?: ""
    val age = ageInput.toIntOrNull() ?: 0

    println("Hello, $name!")

    if (age < 0) {
        println("Please enter a positive number next time.")
    } else if (age in 1..17) {
        println("You are under 18")
    } else if (age in 18..64) {
        println("You are over 18, i.e. an adult")
    } else if (age >= 65) {
        println("You are an elderly person.")
    } else {
        println("Unable to determine the age group since you did not enter a valid number for age.")
    }
}

// EX 6 function declaration

fun divisionFunc() {
    println("Please enter the first number: ")
    val firstNum = readLine() ?: ""
    val numOne = firstNum.toFloat()
    println("Please enter the second number to divide by: ")
    val secondNum = readLine() ?: ""
    val numTwo = secondNum.toFloat()
    if(numTwo == (0).toFloat()) {
        println("Please make sure the second number is not zero.")
        println("Division by zero cannot be performed.")
    } else {
        println("The result: $numOne/$numTwo = ${numOne/numTwo}")
    }



}

// EX 8 Class Person definition
open class Person(name: String, age: Int) {

    private val name: String = name
    private val age: Int = age


    fun getName(): String {
        return this.name
    }

    fun getAge(): Int {
        return this.age
    }

    fun displayPerson() {
        println("The person's name is ${this.name} and age is ${this.age}")
    }


}

//EX 9 Class Person extension
class Male(name: String, age: Int) : Person(name, age) {

    private val age: Int = age
    private val name: String = name

    fun lifeStage() {
        if (this.age < 0) {
            println("Error: Negative number entered for age.")
        } else if (this.age in 1..12) {
            println("You are ${this.age} year(s) old. You are a child")
        } else if (this.age in 13..19) {
            println("You are ${this.age} years old. You are a teenager.")
        } else if (this.age in 20..26) {
            println("You are ${this.age} years old. You are a young adult")
        } else if(this.age in 27..64) {
            println("You are ${this.age} years old. You are an adult")
        } else if(this.age >= 65) {
            println("You are ${this.age} years old. You are an elderly person.")
        } else {
            println("Unable to determine the age group since a valid number was not passed for age.")
        }
    }

}