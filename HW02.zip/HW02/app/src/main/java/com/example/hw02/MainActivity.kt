package com.example.hw02

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.hw02.ui.theme.HW02Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HW02Theme {
                entireApp()
            }
        }
    }
}

@Composable
fun entireApp() {
    val navConroller = rememberNavController()

    NavHost(navController = navConroller, startDestination = "Screen1") {
        composable(
            route = "Screen1",
        ) {
            WelcomeScreenCompose(navController = navConroller)
        }
        composable(route = "Screen2") {
            ListScreen(navController = navConroller)
        }
    }
}


@Preview
@Composable
fun ScreenPreview() {
    entireApp()
}