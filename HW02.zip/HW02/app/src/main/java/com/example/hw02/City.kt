package com.example.hw02

import android.media.Image

data class City(val name: String, val country: String, val population: Float, val logo: Int)
