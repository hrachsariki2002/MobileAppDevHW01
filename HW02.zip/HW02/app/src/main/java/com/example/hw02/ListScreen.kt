package com.example.hw02

import android.media.Image
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController

@Composable
fun ListScreen(navController: NavController) {
    val cities = listOf(
        City("Yerevan", "Armenia", 1.075.toFloat(), logo = R.drawable.yerevan),
        City("Washington", "USA", 7.739.toFloat(), logo = R.drawable.washington),
        City("Madrid", "Spain", 3.223.toFloat(), logo = R.drawable.madrid)
    )

    Column(modifier = Modifier
        .fillMaxSize()
        .background(Color(0xFFE0F4FF))
        .padding(16.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally) {
        ListOfCities(cityList = cities)
        Button(onClick = {
            navController.navigate("Screen1")
        },
            modifier = Modifier.padding(16.dp)
        ) {
            Text("Go to 1st screen")
        }
    }

}

@Composable
fun CityListItem(city: City) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF87C4FF))
            .padding(5.dp)
            .border(1.dp, Color(0xFF39A7FF)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,

    ) {

            Text(
                text = city.name, modifier = Modifier
                    .padding(16.dp),
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        Text(text = "This city is located in ${city.country}. Its population is ${city.population} million.")



        Image(
            painter = painterResource(id = city.logo),
            contentDescription = "${city.name} image",
            modifier = Modifier.size(50.dp, 100.dp)
        )


    }
    Spacer(modifier = Modifier.padding(1.dp))
}

@Composable
fun ListOfCities(cityList: List<City>) {

    LazyColumn {
        items(cityList) {
            city -> CityListItem(city = city)
        }
    }

}

@Preview
@Composable
fun ListScreenPreview() {
    ListScreen(navController = rememberNavController())
}